﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using GoPuffSearch;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;

namespace GoPuff
{
    [TestFixture(typeof(ChromeDriver))]
    public class GoPuff<IWebDriver> where IWebDriver : ChromeDriver, new()
    {
        public ChromeDriver driver = null;

        private string url = Base.Url;
        public string Url { get => url; set => url = value; }
        public AventStack.ExtentReports.ExtentReports extent;
        public ExtentTest test;

        #region Setup

        [OneTimeSetUp]

        public void ReportStartup()
        {

            string reporterPath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin")), @"Reports\GoPuff\"));
            System.IO.Directory.CreateDirectory(reporterPath);
            string errorScreenShotsPath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin")), @"Reports\GoPuff\ErrorScreenShots\"));
            System.IO.Directory.CreateDirectory(errorScreenShotsPath);

            //string reporterPath = "C:\\Reports\\";

            string[] reportList = Directory.GetFiles(reporterPath, "*.html");

            string[] picList = Directory.GetFiles(errorScreenShotsPath, "*.jpg");

            foreach (string report in reportList)
            {
                File.Delete(report);
            }

            foreach (string pic in picList)
            {
                File.Delete(pic);
            }

            ExtentHtmlReporter htmlReporter = new AventStack.ExtentReports.Reporter.ExtentHtmlReporter(reporterPath);
            extent = new AventStack.ExtentReports.ExtentReports();
            extent.AttachReporter(htmlReporter);

        }

        [SetUp]
        public void StartUp()
        {
            ChromeOptions options = new ChromeOptions();
            //options.AddArgument("--headless");
            options.AddArgument("--disable-extensions");
            options.AddArgument("--start-maximized");
            options.AddArgument("--test-type");
            driver = new ChromeDriver(options);
            driver.Navigate().GoToUrl(Url);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
        }
        #endregion

        #region Search
        [Test, Order(1)]
        [Category("Search")]
        public void Search()
        {
            var page = new GoPuffObject(driver);
            test = extent.CreateTest("Enter an address and Search for products");
            page.EnterAddress.Click();
            Thread.Sleep(2000);
            page.EnterYourAddress.Clear();
            Thread.Sleep(5000);
            page.EnterYourAddress.SendKeys("370 Atkins Ave Brooklyn, NY 11208 ");
            Thread.Sleep(2000);
            page.EnterYourAddress.SendKeys(Keys.ArrowDown);
            page.EnterYourAddress.SendKeys(Keys.Enter);
            Thread.Sleep(2000);
            test.Log(Status.Pass, "Confirm address");
            page.ConfirmAddress.Click();
            Thread.Sleep(3000);
            var verifyAddress = page.DeliverTo.Displayed;
            Assert.IsTrue(page.DeliverTo.Displayed, "Address was not found "); // Veryify that correct address was added 
           //Console.WriteLine($"Deliver To : {page.DeliverTo.Text} Address: {verifyAddress}");
            test.Log(Status.Pass, "Deliver To: " + page.DeliverTo.Text);
            test.Log(Status.Pass, "Test passed: " + verifyAddress);

            page.Search.SendKeys("Milk");
            Thread.Sleep(3000);
        }
        #endregion

        #region Failed screen capture 
        public void FailedScreenCapture()
        {
            string screenshotPath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin")), @"Reports\GoPuff\ErrorScreenShots\")); ;

            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stackTrace = "&lt;pre&gt;" + TestContext.CurrentContext.Result.StackTrace + "&lt;/pre&gt;";
            var errorMessage = TestContext.CurrentContext.Result.Message;
            string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            var bitmapName = screenshotPath + TestContext.CurrentContext.Test.Name + ".jpg";

            if (status == TestStatus.Failed)
            {
                var bounds = new Rectangle((driver.Manage().Window.Position.X),
                                             (driver.Manage().Window.Position.Y),
                                             (driver.Manage().Window.Size.Width),
                                             (driver.Manage().Window.Size.Height));

                using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
                {
                    using (Graphics g = Graphics.FromImage(bitmap))
                    {
                        g.CopyFromScreen(new Point(bounds.Left, bounds.Top), Point.Empty, bounds.Size);
                    }
                    bitmap.Save(bitmapName, ImageFormat.Jpeg);
                }

                test.Log(Status.Fail, stackTrace + errorMessage);
                test.Log(Status.Fail, "Snapshot below: " + test.AddScreenCaptureFromPath(bitmapName));

            }
        }
        #endregion

        [TearDown]
        public void CleanUp()
        {
            test.Log(Status.Info, "Exit");
            driver.Quit();
        }
        [OneTimeTearDown]

        public void EndReport()
        {
            extent.Flush();

        }
    }
}


