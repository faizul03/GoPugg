﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace GoPuffSearch
{
    public class GoPuffObject
    {
        public GoPuffObject(ChromeDriver driver)
        {
            PageFactory.InitElements(driver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@placeholder='Enter your address']")]
        public IWebElement EnterAddress { get; set; }
        [FindsBy(How = How.XPath, Using = "//img[@class='lazyimgload puffZoom xcontrol c-maps__clear-search-button']")]
        public IWebElement ClearButton { get; set; }
        [FindsBy(How = How.CssSelector, Using = "#mapSearch")]
        public IWebElement EnterYourAddress { get; set; }
        [FindsBy(How = How.CssSelector, Using = "#mapAddAdddress")]
        public IWebElement ConfirmAddress { get; set; }
        [FindsBy(How = How.CssSelector, Using = "#product-search")]
        public IWebElement Search { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='puffAnimSlower puffRow']")]
        public IWebElement DeliverTo { get; set; }

    }
}
