﻿using OpenQA.Selenium.Chrome;
using System;

namespace GoPuff
{
    public class Base
    {
        public static ChromeDriver driver;
        public static string Url = "https://gopuff.com";
    }
}
